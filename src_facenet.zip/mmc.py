from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys
import os
import tensorflow as tf
import numpy as np
import facenet
import detect_face
import cv2
from scipy import misc
import math
import pickle
from sklearn.svm import SVC
import matplotlib.pyplot as plt
import matplotlib.image as mpimg


######################
image_size = 160
detect_multiple_faces = False
margin = 32
#--par--Classifier----#
batch_size = 100
seed = 666

input_img = "aaa.png"
output_img = "new.jpg"
CLASSIFIER_FILENAME = '~/caf/facenet_google/model22/my_model.pkl'
MODEL = '~/caf/facenet_google/model22/20170512-110547/20170512-110547.pb'
######################


class load_all():
     def __init__(self):
         print('Loading feature extraction model')
         print("load model!!.pb---- done")
         with tf.Graph().as_default():
            with tf.Session() as sess:
               np.random.seed(seed=seed)
               
               facenet.load_model(MODEL)
               # Get input and output tensors
               self.images_placeholder = tf.get_default_graph().get_tensor_by_name("input:0")
               self.embeddings = tf.get_default_graph().get_tensor_by_name("embeddings:0")
               self.phase_train_placeholder = tf.get_default_graph().get_tensor_by_name("phase_train:0")
               self.embedding_size = self.embeddings.get_shape()[1]
               self.sess = sess

         self.classifier_filename_exp = os.path.expanduser(CLASSIFIER_FILENAME)
         with open(self.classifier_filename_exp, 'rb') as infile:
              (self.model, self.class_names) = pickle.load(infile)
         print('Loaded classifier model from file "%s"' % self.classifier_filename_exp)
         print("load_all--- done")
#-----------Classifier------------#
def classifier_my(nrof_faces,paths_batch,load_m):
            cv2.imwrite('face_d.png', nrof_faces) #misc.imsave('face_d.png', nrof_faces)
            path = np.array(['face_d.png'])

            # Get input and output tensors
            sess = load_m.sess
            images_placeholder = load_m.images_placeholder
            embeddings = load_m.embeddings 
            phase_train_placeholder = load_m.phase_train_placeholder 
            embedding_size = load_m.embedding_size 
            
            # Run forward pass to calculate embeddings
            print('Calculating features for images')
            nrof_images = len(path)
            nrof_batches_per_epoch = int(math.ceil(1.0*nrof_images / batch_size))
            emb_array = np.zeros((nrof_images, embedding_size))
            for i in range(nrof_batches_per_epoch):
                start_index = i*batch_size
                end_index = min((i+1)*batch_size, nrof_images)
                paths_batch = path[start_index:end_index]
                images = facenet.load_data(paths_batch, False, False, image_size)
                feed_dict = { images_placeholder:images, phase_train_placeholder:False }
                emb_array[start_index:end_index,:] = sess.run(embeddings, feed_dict=feed_dict)
            
            class_names = load_m.class_names
            model = load_m.model
            print('Testing classifier')
            predictions = model.predict_proba(emb_array)
            best_class_indices = np.argmax(predictions, axis=1)
            best_class_probabilities = predictions[np.arange(len(best_class_indices)), best_class_indices]
                
            for i in range(len(best_class_indices)):
                 print('%4d  %s: %.3f' % (i, class_names[best_class_indices[i]], best_class_probabilities[i]))
                 name_w = class_names[best_class_indices[i]]
                 acc_best = best_class_probabilities[i]
            labels = len(path)
            accuracy = np.mean(np.equal(best_class_indices, labels))
            print('Accuracy: %.3f' % accuracy)
            return name_w,acc_best

def crop_align(img,bounding_boxes,face_num):
    bounding_boxes = np.array([bounding_boxes])

    nrof_faces = bounding_boxes.shape[0]
    if nrof_faces>0:
       det = bounding_boxes[:,0:4]
       det_arr = []
       img_size = np.asarray(img.shape)[0:2]
       if nrof_faces>1:
          if detect_multiple_faces:
             for i in range(nrof_faces):
                 det_arr.append(np.squeeze(det[i]))
          else:
              bounding_box_size = (det[:,2]-det[:,0])*(det[:,3]-det[:,1])
              img_center = img_size / 2
              offsets = np.vstack([ (det[:,0]+det[:,2])/2-img_center[1], (det[:,1]+det[:,3])/2-img_center[0] ])
              offset_dist_squared = np.sum(np.power(offsets,2.0),0)
              index = np.argmax(bounding_box_size-offset_dist_squared*2.0) # some extra weight on the centering
              det_arr.append(det[index,:])
       else:
           det_arr.append(np.squeeze(det))

    for i, det in enumerate(det_arr):
      det = np.squeeze(det)
      bb = np.zeros(4, dtype=np.int32)
      bb[0] = np.maximum(det[0]-margin/2, 0)
      bb[1] = np.maximum(det[1]-margin/2, 0)
      bb[2] = np.minimum(det[2]+margin/2, img_size[1])
      bb[3] = np.minimum(det[3]+margin/2, img_size[0])
      cropped = img[bb[1]:bb[3],bb[0]:bb[2],:]
      scaled = misc.imresize(cropped, (image_size, image_size), interp='bilinear')
      misc.imsave("mmmmm%s.jpg"% face_num, scaled)
      return scaled

def main():
    load_m = load_all()
    sess = tf.Session()
    pnet, rnet, onet = detect_face.create_mtcnn(sess, None)
    
    minsize = 40 # minimum size of face
    threshold = [ 0.6, 0.7, 0.9 ]  # three steps's threshold
    factor = 0.709 # scale factor

    
    filename = input_img
    output_filename =output_img


    draw = cv2.imread(filename)

    img=draw.copy() #cv2.cvtColor(draw,cv2.COLOR_BGR2RGB)
    
    bounding_boxes, points = detect_face.detect_face(img, minsize, pnet, rnet, onet, threshold, factor)

    nrof_faces = bounding_boxes.shape[0]


    k=0
    for b in bounding_boxes:
        k +=1
        cv2.rectangle(draw, (int(b[0]), int(b[1])), (int(b[2]), int(b[3])), (0, 255, 0))
        print(b)
        cut_face=crop_align(img,b,k)
        name_w,acc_best = classifier_my(cut_face,nrof_faces,load_m)
        if acc_best < 0.80:
           cv2.putText(draw,'face!: unknown !',(int(b[0])-96, int(b[1])-0), 5,1,(255, 255, 0))
        else:
           cv2.putText(draw,'face!: %s acc={%.3f}' % (name_w,acc_best),(int(b[0])-96, int(b[1])-0), 3,1,(0, 255, 0),2)
    for p in points.T:
        for i in range(5):
            cv2.circle(draw, (p[i], p[i + 5]), 1, (0, 0, 255), 2)

    cv2.imwrite(output_filename,draw)
    vvv= np.zeros((0, image_size, image_size, 3))
    cv2.imwrite('vvv.jpg',vvv)
    print('Total %d face(s) detected, saved in %s' % (nrof_faces,output_filename))
    #plt.figure()
    #plt.imshow(draw)
    #plt.show()
    cv2.imshow('face!!',draw)
    if cv2.waitKey(0) == ord('q'):
       print("goodby!")
       cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
